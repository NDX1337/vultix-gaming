addEvent('onPlayerRaceWasted',true)
addEventHandler('onPlayerRaceWasted',root,
	function(v)
if( string.find(getResourceInfo(exports.mapmanager:getRunningGamemodeMap(), "name"), "RS", 1, true)) then return end
		setTimer(function()
		if v then
			local x,y,z = getElementPosition(v)
			setElementPosition(v,x,y,-10)
		end
		end,850,1)
	end
)