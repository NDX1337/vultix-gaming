setCameraClip (false,false)
function camerafix()
setCameraClip (false,false)
end
addEventHandler("onClientResourceStart", resourceRoot, camerafix)