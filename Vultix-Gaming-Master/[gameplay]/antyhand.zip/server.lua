function RGBToHex(red, green, blue, alpha)
	if((red < 0 or red > 255 or green < 0 or green > 255 or blue < 0 or blue > 255) or (alpha and (alpha < 0 or alpha > 255))) then
		return nil
	end
	if(alpha) then
		return string.format("#%.2X%.2X%.2X%.2X", red,green,blue,alpha)
	else
		return string.format("#%.2X%.2X%.2X", red,green,blue)
	end
end


addCommandHandler("handling",
function (p,_)
outputChatBox(" ",root,255,0,0,true)
outputChatBox(" ",root,255,0,0,true)
for i ,v in ipairs (getElementsByType("player")) do 
local id = getElementModel ( getPedOccupiedVehicle(v) )
local autoid = tonumber(id)
if getElementData(v,"state") == "alive" then
local handling = getVehicleHandling(getPedOccupiedVehicle(v))
local ohandling = getOriginalHandling(autoid)
local team = getPlayerTeam(v)
if team then
local r, g, b  = getTeamColor(team)
local hex = RGBToHex (r, g, b)
outputChatBox(hex..getPlayerName(v).."#0066ffhas mass #FFFFFF"..ohandling["mass"].."#0066ff orginal is #FFFFFF"..ohandling["mass"].." #ff0000|| #0066ffturnMass #FFFFFF"..ohandling["turnMass"].."#0066ff orginal is #FFFFFF"..ohandling["turnMass"],root,255,100,0,true )
else
outputChatBox("#FFFFFF"..getPlayerName(v).."#0066ffhas mass is #FFFFFF"..ohandling["mass"].."#0066ff orginal is #FFFFFF"..ohandling["mass"].." #ff0000|| #0066ffturnMass #FFFFFF"..ohandling["turnMass"].."#0066ff orginal is #FFFFFF"..ohandling["turnMass"],root,255,100,0,true )
end
end
end
outputChatBox(" ",root,255,0,0,true)
outputChatBox(" ",root,255,0,0,true)
end)


function auto()
local handTable = {"mass","turnMass","percentSubmerged","dragCoeff","tractionLoss","tractionMultiplier","tractionBias","numberOfGears","engineInertia","engineAcceleration","brakeBias","maxVelocity","brakeDeceleration","engineType","driveType","suspensionForceLevel","steeringLock","ABS","animGroup","tailLight","headLight","handlingFlags","modelFlags","monetary","collisionDamageMultiplier","seatOffsetDistance","suspensionAntiDiveMultiplier","suspensionFrontRearBias","suspensionLowerLimit","suspensionUpperLimit","suspensionHighSpeedDamping","suspensionDamping"}
local player = getVehicleController(source)
local id = getElementModel(source)
local autoid = tonumber(id)
local serial = getPlayerSerial(player)
local handling = getVehicleHandling(source)
local ohandling = getOriginalHandling(autoid)
for i,hand in ipairs(handTable) do
if handling[hand] ~= ohandling[hand] then
local team = getPlayerTeam(v)
if team then
local r, g, b  = getTeamColor(team)
local hex = RGBToHex (r, g, b)
outputChatBox(hex..getPlayerName(player).."#0066ff has "..hand.." changed from #20b200"..ohandling[hand].." #0066ffto #AA0000"..ohandling[hand], root, 255,100,0,true)
else
outputChatBox("#FFFFFF"..getPlayerName(player).."#0066ff has "..hand.." from #20b200"..ohandling[hand].." #0066ffto #AA0000"..ohandling[hand], root, 255,100,0,true)
end
end
end
end
