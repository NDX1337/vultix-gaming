--[[
       
       ***           ***    ***       ***              ***      ***      ***       ***          *   *        ***         ***    ***      ***          
       ******     ******    *************              ************      *************          *****        *****      ****    ************          
       ******     ******    **************            ******   ******    **** *********        ******        ******     ****    *************         
       *******   *******    ***        ****          ****        ****    ***        ****      ********       *******    ****    ***       ****        
       *** ***   *** ***    ***       ****           ***                 ***        ****      ***  ****      ********   ****    ***        ****       
       *** ***  **** ***    **************          ****      **** **    **************      ****   ***      **** ****  ****    ***        ****       
       ***  *** ***  ***    ***********             ****     *********   ***********        ****    ****     ****  **** ****    ***        ****       
       ***  *******  ***    ***    *****             ****         ***    ***    *****       *************    ****   ********    ***        ****       
       ***  ******   ***    ***      ****            *****        ***    ***      ****     **************    ****    *******    ***       ****        
       ***   *****   ***    ***       ****    ****    ******* *******    ***       ****   ****        ****   ****     ******    *************         
       ***   ****    ***    ***        ****   ****      ***********      ****       ****  ***          ****  ****      *****    ***********            
--]]



skins = {
{ "Skin 1", 0 },
{ "Skin 2", 269 },
{ "Skin 3", 300 },
{ "Skin 4", 220 },
{ "Skin 5", 240 },
{ "Skin 6", 123 },
{ "Skin 7", 71 },
{ "Skin 8", 223 },
{ "Skin 9", 150 },
{ "Skin 10", 24 },
{ "Skin 11", 120 },
{ "Skin 12", 299 },
{ "Skin 13", 133 },
{ "Skin 14", 165 },
{ "Skin 15", 186 },
{ "Skin 16", 264 },
{ "Skin 17", 73 },
{ "Skin 18", 253 },
{ "Skin 19", 180 },
{ "Skin 20", 116 },
{ "Skin 21", 102 },
{ "Skin 22", 97 },
{ "Skin 23", 78 },
{ "Skin 24", 150 },
{ "Skin 25", 28 },
{ "Skin 26", 19 },
{ "Skin 27", 22 },
{ "Skin 28", 138 },
{ "Skin 29", 197 },
{ "Skin 30", 228 },
}



Skin_changer = guiCreateButton(0.54, 0.28, 0.10, 0.04, "# Change skin", true)
guiSetVisible( Skin_changer, false)
guiSetFont(Skin_changer, "default-bold-small")
guiSetProperty(Skin_changer, "NormalTextColour", "FFFCFCFC")
Skins_close = guiCreateButton(0.54, 0.74, 0.10, 0.04, "# Close panel", true)
guiSetVisible( Skins_close, false)
guiSetFont(Skins_close, "default-bold-small")
guiSetProperty(Skins_close, "NormalTextColour", "FFFCFCFC")
Skins_grid = guiCreateGridList(0.36, 0.27, 0.17, 0.53, true)
guiSetVisible( Skins_grid, false)
guiGridListAddColumn(Skins_grid, "Skins ", 0.5)
guiGridListAddColumn(Skins_grid, "ID ", 0.5)

local screenW, screenH = guiGetScreenSize()

function Skins_panel()
        dxDrawLine((screenW * 0.3543) - 1, (screenH * 0.2005) - 1, (screenW * 0.3543) - 1, screenH * 0.8008, tocolor(0, 0, 0, 255), 1, false)
        dxDrawLine(screenW * 0.6457, (screenH * 0.2005) - 1, (screenW * 0.3543) - 1, (screenH * 0.2005) - 1, tocolor(0, 0, 0, 255), 1, false)
        dxDrawLine((screenW * 0.3543) - 1, screenH * 0.8008, screenW * 0.6457, screenH * 0.8008, tocolor(0, 0, 0, 255), 1, false)
        dxDrawLine(screenW * 0.6457, screenH * 0.8008, screenW * 0.6457, (screenH * 0.2005) - 1, tocolor(0, 0, 0, 255), 1, false)
        dxDrawRectangle(screenW * 0.3543, screenH * 0.2005, screenW * 0.2914, screenH * 0.6003, tocolor(0, 0, 0, 194), false)
        dxDrawText("Vultix Skin Panel", (screenW * 0.3543) - 1, (screenH * 0.2005) - 1, (screenW * 0.6457) - 1, (screenH * 0.2604) - 1, tocolor(252, 252, 252, 255), 1.00, "bankgothic", "center", "center", false, false, false, false, false)
    end
	
function OPEN()
	if removeEventHandler('onClientRender', root, Skins_panel) then
	removeEventHandler('onClientRender', root, Skins_panel)
	guiSetVisible(Skins_grid,false)
	guiSetVisible(Skin_changer,false)
	guiSetVisible(Skins_close,false)
	showCursor(false)
else
	addEventHandler('onClientRender', root, Skins_panel)
	guiSetVisible(Skins_grid,true)
	guiSetVisible(Skin_changer,true)
	guiSetVisible(Skins_close,true)
	showCursor(true)
end
end
	bindKey( "F10", "down", OPEN)

for i,v in ipairs( skins ) do
	row = guiGridListAddRow(Skins_grid)
	guiGridListSetItemText( Skins_grid, row, 1, tostring(v[1]), false, false )
	guiGridListSetItemText( Skins_grid, row, 2, tonumber(v[2]), false, false )
	guiGridListSetItemData( Skins_grid, row, 1, tonumber(v[2]) )
end

addEventHandler('onClientGUIClick', root, 
function()
	if (source == Skins_close) then
	removeEventHandler('onClientRender', root, Skins_panel)
	guiSetVisible(Skins_grid,false)
	guiSetVisible(Skin_changer,false)
	guiSetVisible(Skins_close,false)
	showCursor(false)
	elseif (source == Skin_changer) then
	local Data = guiGridListGetItemData( Skins_grid, guiGridListGetSelectedItem ( Skins_grid ), 1 )
	triggerServerEvent( 'ChangeSkin', localPlayer, Data )
	outputChatBox('Skin Changed seccessfully !',255,255,255,true)
	saveSkinConfig(Data)
end
end 
)

addEventHandler( "onClientResourceStart", getRootElement( ),
    function ()
        loadSkinConfig()
    end
);

-- Saving nos RGB values to xml
function saveSkinConfig(data)
	local xml = xmlLoadFile("conf.xml")
	if not xml then
		xml = xmlCreateFile("conf.xml","config")
		xmlNodeSetAttribute(xml,"data",data)
	else
		xmlNodeSetAttribute(xml,"data",data)
	end
	xmlSaveFile(xml)
	xmlUnloadFile(xml)
end


-- Getting nos RGB values from xml
function loadSkinConfig()
	local xml = xmlLoadFile("conf.xml")
	if xml then
		local data = xmlNodeGetAttribute(xml,"data")
		triggerServerEvent( 'ChangeSkin', localPlayer, data )
	end
	xmlUnloadFile(xml)	
end









