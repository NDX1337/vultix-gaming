-------------------------------------------------
--*   (c) 2013  Twin Stars www.ts-mta.com     *--
--*           Script create by JoZeF*         *--
-------------------------------------------------

txd = engineLoadTXD ( "dynbarrels.txd" )
engineImportTXD ( txd, 1225 )


---------------------------------------------------
-- End and Security Good luck taking this script --
---------------------------------------------------
fileDelete ("nacitat.lua")