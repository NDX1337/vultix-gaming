-- *** This Script By Al3grab 2011 ***
-- *** IF You Are Editing The Script or installing it Dont Remove This Lines ***
-- *** Al3grab 2011 - Chat Disable Script ***
-- *** To Disable Chat Use Command : /cd ***
-- *** To Enable Chat Use Command : /ce ***
-- *** تم صنع المود بواسطة Al3grab 2011 ***
-- *** عند تركيب المود أو تعديله الرجاء عدم إزالة هذه النصوص ***
-- *** Al3grab 2011 - مود تعطيل الشات | منع اللاعبين من الكتابة في الشات ***
-- *** لتعطيل الشات إكتب الأمر التالي : /cd ***
-- *** لتشغيل الشات إكتب الأمر التالي : /ce ***

-- --------------------------------- --
-- *** Script Code | Server-Side *** --
-- --------------------------------- --

-- *** Disabling Code | Start ***
function chatDis(command)
		cancelEvent()
		outputChatBox("*** THE CHAT IS DISABLED ***",source,255,0,0)
	if hasObjectPermissionTo ( command, "function.banPlayer" ) then
		addEventHandler("onPlayerChat",getRootElement(),chatDis)
end	end
-- *** Disabling Code | End ***

-- *** Enabling Code | Start ***
function chatEN(command)
	if hasObjectPermissionTo ( command, "function.banPlayer" ) then
		outputChatBox("*** THE CHAT IS NOW ENABLED ***",getRootElement(),255,0,0)
		removeEventHandler("onPlayerChat",getRootElement(),chatDis)
end	end
-- *** Enabling Code | End ***

-- *** Adding Commands | Start ***
addCommandHandler("cd",chatDis)
addCommandHandler("ce",chatEN)
-- *** Adding Commands | End ***

-- ---------------------------- --
-- *** Script Code | THE - END  --
-- ---------------------------- --

-- Love : Al3grab ;p