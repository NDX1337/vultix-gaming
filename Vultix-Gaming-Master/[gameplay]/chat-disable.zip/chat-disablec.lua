-- *** On Start/Stop Code ***

addEventHandler("onClientResourceStart", getResourceRootElement(getThisResource()), function()
    outputChatBox("#FF0000 *** CHAT DISABLE - SCRIPT BY AL3GRAB *** ", 255,0,0,true)
end
)

addEventHandler("onClientResourceStop", getResourceRootElement(getThisResource()), function()
    outputChatBox("#FF0000 *** CHAT DISABLE HAS STOPPED - SCRIPT BY AL3GRAB *** ", 255,0,0,true)
end
)

-- *** On Start/Stop Code ***